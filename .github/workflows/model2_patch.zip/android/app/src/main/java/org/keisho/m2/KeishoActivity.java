package org.keisho.m2;

import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.WindowManager;
import android.view.ViewGroup;
import org.libsdl.app.SDLActivity;
import java.io.*;
import java.util.Arrays;
import java.util.List;

public class KeishoActivity extends SDLActivity {
    static final String ROM_DIR = "/storage/emulated/0/Model 2";
    static final List<String> GUN_GAMES = Arrays.asList(
        "hotd", "hotdo", "hotdp", "gunblade", "vcop", "vcop2", "dynamcop", "dynamcopb", "dynamcopc", "bel", "zerogun");
    String game = "hotd";
    int mode = HudOverlay.MODE_RACE;

    @Override
    protected void onCreate(Bundle b) {
        String g = getIntent().getStringExtra("game");
        if (g != null) {
            game = g;
            mode = getIntent().getIntExtra("mode", HudOverlay.MODE_PAD);
        } else {
            // legacy path: set name from assets/game.txt, optionally overridden by /Model 2/game.txt
            try { game = readAsset("game.txt").trim(); } catch (Exception e) { /* default */ }
            try {
                File ov = new File(ROM_DIR, "game.txt");
                if (ov.exists()) {
                    try (BufferedReader r = new BufferedReader(new FileReader(ov))) {
                        String l = r.readLine();
                        if (l != null && !l.trim().isEmpty()) game = l.trim();
                    }
                }
            } catch (Exception ignored) {}
            mode = GUN_GAMES.contains(game) ? HudOverlay.MODE_GUN : HudOverlay.MODE_RACE;
        }
        copyAssets("", getFilesDir());
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {}
        }
        dumpLogcat();
        super.onCreate(b);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        addContentView(new HudOverlay(this, mode),
            new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // Single-game boot: straight into the game, no Keisho picker.
    @Override
    protected String[] getArguments() {
        if (mode == HudOverlay.MODE_GUN) {
            return new String[]{"--game", game, "--rom-dir", ROM_DIR, "--graphics-backend", "opengl", "--fullscreen", "--lightgun"};
        }
        return new String[]{"--game", game, "--rom-dir", ROM_DIR, "--graphics-backend", "opengl", "--fullscreen"};
    }

    // Own-UID logcat (includes the previous run's native crash) -> /storage/emulated/0/Model 2/logcat.txt
    void dumpLogcat() {
        try {
            File dir = new File(ROM_DIR); dir.mkdirs();
            Process pr = Runtime.getRuntime().exec(new String[]{"logcat", "-d", "-v", "time"});
            try (InputStream in = pr.getInputStream(); OutputStream os = new FileOutputStream(new File(dir, "logcat.txt"))) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
        } catch (Exception ignored) {}
    }

    String readAsset(String name) throws IOException {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream o = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toString("UTF-8");
        }
    }

    void copyAssets(String path, File dest) {
        try {
            AssetManager am = getAssets();
            String[] list = am.list(path);
            if (list == null) return;
            if (list.length == 0) { // file
                File out = new File(dest, path);
                out.getParentFile().mkdirs();
                try (InputStream in = am.open(path); OutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
            } else {
                for (String s : list) copyAssets(path.isEmpty() ? s : path + "/" + s, dest);
            }
        } catch (IOException ignored) {}
    }
}

package org.keisho.m2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.*;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.FrameLayout;
import org.libsdl.app.SDLActivity;

/** Standard minimalist HUD: top-right cluster, coin/start, pad + pedals (racers), Quick options. */
public class HudOverlay extends FrameLayout {
    public static final int MODE_GUN = 0, MODE_RACE = 1, MODE_PAD = 2;
    final Activity act; final int mode;
    final java.util.ArrayList<View> controls = new java.util.ArrayList<>();
    final SharedPreferences prefs;
    final float d;
    final Handler h = new Handler(Looper.getMainLooper());
    View coin, start, test, service;
    boolean paused = false;

    static final int K_COIN = KeyEvent.KEYCODE_5, K_START = KeyEvent.KEYCODE_1,
        K_TEST = KeyEvent.KEYCODE_0, K_SERVICE = KeyEvent.KEYCODE_9,
        K_PAUSE = KeyEvent.KEYCODE_P, K_OVERLAY = KeyEvent.KEYCODE_F10,
        K_SAVE = KeyEvent.KEYCODE_F6, K_LOAD = KeyEvent.KEYCODE_F7,
        K_GAS = KeyEvent.KEYCODE_CTRL_LEFT, K_BRAKE = KeyEvent.KEYCODE_ALT_LEFT,
        K_SHIFT_UP = KeyEvent.KEYCODE_Z, K_SHIFT_DN = KeyEvent.KEYCODE_X;

    public HudOverlay(Context c, int mode) {
        super(c);
        this.act = (Activity) c; this.mode = mode;
        d = c.getResources().getDisplayMetrics().density;
        prefs = c.getSharedPreferences("hud", 0);
        build();
        applyPrefs();
    }

    static void key(int code, boolean down) {
        if (down) SDLActivity.onNativeKeyDown(code); else SDLActivity.onNativeKeyUp(code);
    }
    void tap(int code) { key(code, true); h.postDelayed(() -> key(code, false), 60); }
    int dp(float v) { return (int) (v * d); }

    void build() {
        setClipChildren(false);
        // top-right cluster: play/pause, aspect/video, menu
        add(new Btn(getContext(), Btn.PLAY, 0, v -> togglePause()), 44, 44, Gravity.TOP | Gravity.END, 0, 10, 112, 0);
        add(new Btn(getContext(), Btn.ASPECT, 0, v -> tap(K_OVERLAY)), 44, 44, Gravity.TOP | Gravity.END, 0, 10, 62, 0);
        add(new Btn(getContext(), Btn.MENU, 0, v -> showQuickOptions()), 44, 44, Gravity.TOP | Gravity.END, 0, 10, 12, 0);

        coin = add(new Btn(getContext(), Btn.PILL, K_COIN, null).label("COIN"), 86, 34, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0, 190, 10);
        start = add(new Btn(getContext(), Btn.PILL, K_START, null).label("START"), 86, 34, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 190, 0, 0, 10);
        test = add(new Btn(getContext(), Btn.PILL, K_TEST, null).label("TEST"), 70, 30, Gravity.BOTTOM | Gravity.START, 190, 0, 0, 10);
        service = add(new Btn(getContext(), Btn.PILL, K_SERVICE, null).label("SERVICE"), 70, 30, Gravity.BOTTOM | Gravity.START, 270, 0, 0, 10);
        test.setVisibility(GONE); service.setVisibility(GONE);

        controls.add(coin); controls.add(start);
        if (mode == MODE_RACE) {
            controls.add(add(new Pad(getContext()), 150, 150, Gravity.BOTTOM | Gravity.START, 24, 0, 0, 24));
            controls.add(add(new Btn(getContext(), Btn.ROUND, K_BRAKE, null).label("BRAKE").color(0xFFD9573A), 78, 78, Gravity.BOTTOM | Gravity.END, 0, 0, 100, 22));
            controls.add(add(new Btn(getContext(), Btn.ROUND, K_GAS, null).label("GAS").color(0xFF6BBF3A), 86, 86, Gravity.BOTTOM | Gravity.END, 0, 0, 14, 18));
            controls.add(add(new Btn(getContext(), Btn.PILL, K_SHIFT_UP, null).label("+"), 44, 34, Gravity.BOTTOM | Gravity.END, 0, 0, 14, 116));
            controls.add(add(new Btn(getContext(), Btn.PILL, K_SHIFT_DN, null).label("-"), 44, 34, Gravity.BOTTOM | Gravity.END, 0, 0, 66, 116));
        } else if (mode == MODE_PAD) {
            controls.add(add(new Pad(getContext()), 150, 150, Gravity.BOTTOM | Gravity.START, 24, 0, 0, 24));
            int[] codes = {KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_C, KeyEvent.KEYCODE_V};
            String[] names = {"A", "B", "C", "D"};
            int[] rs = {100, 14, 100, 14}, bs = {22, 22, 108, 108};
            for (int k = 0; k < 4; k++) {
                controls.add(add(new Btn(getContext(), Btn.ROUND, codes[k], null).label(names[k]).color(0xFFEEEEEE), 76, 76, Gravity.BOTTOM | Gravity.END, 0, 0, rs[k], bs[k]));
            }
        }
        setOnApplyWindowInsetsListener((v, ins) -> {
            int l = dp(12), r = dp(48);   // keep clear of the edge: system bars can slide over it
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = ins.getInsetsIgnoringVisibility(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                l = Math.max(l, bars.left); r = Math.max(r, bars.right);
            }
            setPadding(l, 0, r, 0);
            return ins;
        });
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); requestApplyInsets(); }

    View add(View v, int w, int hh, int grav, int l, int t, int r, int b) {
        LayoutParams lp = new LayoutParams(dp(w), dp(hh), grav);
        lp.setMargins(dp(l), dp(t), dp(r), dp(b));
        addView(v, lp);
        return v;
    }

    void togglePause() { paused = !paused; tap(K_PAUSE); }

    void applyPrefs() {
        float a = prefs.getFloat("opacity", 0.8f);
        boolean cs = prefs.getBoolean("coinstart", true), ts = prefs.getBoolean("testservice", false);
        for (View v : controls) v.setAlpha(a);
        coin.setVisibility(cs ? VISIBLE : GONE); start.setVisibility(cs ? VISIBLE : GONE);
        test.setVisibility(ts ? VISIBLE : GONE); service.setVisibility(ts ? VISIBLE : GONE);
        test.setAlpha(a); service.setAlpha(a);
    }

    void showQuickOptions() {
        if (!paused) togglePause();
        boolean cs = prefs.getBoolean("coinstart", true), ts = prefs.getBoolean("testservice", false);
        float a = prefs.getFloat("opacity", 0.8f);
        String[] items = {
            "Exit game", "Video settings", "Controls opacity: " + Math.round(a * 100) + "%",
            "Coin / Start: " + (cs ? "Shown" : "Hidden"), "Test / Service: " + (ts ? "Shown" : "Hidden"),
            "Controller mapping", "Save state (slot)", "Load state (slot)", "Restart game", "Cancel"};
        new AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Quick options")
            .setItems(items, (dlg, i) -> {
                boolean reopen = false;
                switch (i) {
                    case 0: act.finish(); h.postDelayed(() -> android.os.Process.killProcess(android.os.Process.myPid()), 150); return;
                    case 1: case 5: tap(K_OVERLAY); break; // Keisho's own settings overlay
                    case 2: prefs.edit().putFloat("opacity", a > 0.7f ? 0.5f : a > 0.4f ? 0.25f : 1.0f).apply(); reopen = true; break;
                    case 3: prefs.edit().putBoolean("coinstart", !cs).apply(); reopen = true; break;
                    case 4: prefs.edit().putBoolean("testservice", !ts).apply(); reopen = true; break;
                    case 6: tap(K_SAVE); break;
                    case 7: tap(K_LOAD); break;
                    case 8: {
                        Intent in = new Intent(act.getIntent());
                        act.finish();
                        act.startActivity(in);
                        h.postDelayed(() -> android.os.Process.killProcess(android.os.Process.myPid()), 250);
                        return;
                    }
                }
                applyPrefs();
                if (reopen) { showQuickOptions(); return; }
                if (paused && i != 1 && i != 5) togglePause();
            })
            .setOnCancelListener(x -> { if (paused) togglePause(); })
            .show();
    }

    // ---- views ----
    static class Btn extends View {
        static final int PLAY = 0, ASPECT = 1, MENU = 2, PILL = 3, ROUND = 4;
        final int kind, code; String text = ""; int color = 0xFFFFFFFF;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final OnClickListener click; boolean down;
        Btn(Context c, int kind, int code, OnClickListener click) { super(c); this.kind = kind; this.code = code; this.click = click; }
        Btn label(String t) { text = t; return this; }
        Btn color(int c) { color = c; return this; }
        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: down = true; invalidate(); if (code != 0) key(code, true); return true;
                case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
                    if (down) { down = false; invalidate(); if (code != 0) key(code, false); else if (click != null && e.getActionMasked() == MotionEvent.ACTION_UP) click.onClick(this); }
                    return true;
            }
            return true;
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2;
            p.setStyle(Paint.Style.FILL);
            p.setColor(down ? 0xCC444444 : 0x99000000);
            if (kind == PILL) { c.drawRoundRect(0, 0, w, h, h / 2, h / 2, p); p.setColor(0xFFEEEEEE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(h * 0.5f); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(text, cx, cy + h * 0.18f, p); return; }
            if (kind == ROUND) { p.setColor(down ? 0xAA888888 : 0x88DDDDDD); c.drawCircle(cx, cy, Math.min(cx, cy), p); p.setColor(color); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(h * 0.2f); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(text, cx, cy + h * 0.07f, p); return; }
            c.drawCircle(cx, cy, Math.min(cx, cy), p);
            p.setColor(Color.WHITE); p.setStrokeWidth(h * 0.07f); p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND);
            if (kind == MENU) { for (int i = -1; i <= 1; i++) c.drawLine(w * .3f, cy + i * h * .14f, w * .7f, cy + i * h * .14f, p); }
            else if (kind == PLAY) { p.setStyle(Paint.Style.FILL); Path t = new Path(); t.moveTo(w * .30f, h * .30f); t.lineTo(w * .30f, h * .70f); t.lineTo(w * .55f, cy); t.close(); c.drawPath(t, p); c.drawRect(w * .62f, h * .30f, w * .67f, h * .70f, p); c.drawRect(w * .72f, h * .30f, w * .77f, h * .70f, p); }
            else { float a = w * .28f, b = w * .72f, l = w * .14f; // four corner brackets
                c.drawLines(new float[]{a,a,a+l,a, a,a,a,a+l, b,a,b-l,a, b,a,b,a+l, a,b,a+l,b, a,b,a,b-l, b,b,b-l,b, b,b,b,b-l}, p); }
        }
    }

    /** Digital steering pad: left/right/up/down from the thumb offset. */
    class Pad extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float tx, ty; boolean l, r, u, dn;
        Pad(Context c) { super(c); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, rad = cx;
            boolean active = e.getActionMasked() != MotionEvent.ACTION_UP && e.getActionMasked() != MotionEvent.ACTION_CANCEL;
            float dx = active ? e.getX() - cx : 0, dy = active ? e.getY() - cy : 0;
            float len = (float) Math.hypot(dx, dy);
            if (len > rad * 0.6f) { dx *= rad * 0.6f / len; dy *= rad * 0.6f / len; }
            tx = dx; ty = dy;
            set(KeyEvent.KEYCODE_DPAD_LEFT, l, l = dx < -rad * 0.12f);
            set(KeyEvent.KEYCODE_DPAD_RIGHT, r, r = dx > rad * 0.12f);
            set(KeyEvent.KEYCODE_DPAD_UP, u, u = dy < -rad * 0.3f);
            set(KeyEvent.KEYCODE_DPAD_DOWN, dn, dn = dy > rad * 0.3f);
            invalidate(); return true;
        }
        void set(int code, boolean was, boolean now) { if (was != now) key(code, now); }
        @Override protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0x55FFFFFF); c.drawCircle(cx, cy, cx, p);
            p.setColor(0x99DDDDDD); c.drawCircle(cx + tx, cy + ty, cx * 0.42f, p);
        }
    }
}

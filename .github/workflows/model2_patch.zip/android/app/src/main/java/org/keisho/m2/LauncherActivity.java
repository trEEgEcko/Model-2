package org.keisho.m2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.xmlpull.v1.XmlPullParser;
import java.io.File;
import java.io.InputStream;
import java.util.*;

/** Lists the games found in /storage/emulated/0/Model 2 and starts the chosen one in its own process. */
public class LauncherActivity extends Activity {
    static class Info { String name, parent, title; Set<String> types = new HashSet<>(); }
    static class Entry { String set, title; int mode; }

    final Map<String, Info> games = new HashMap<>();
    final List<Entry> entries = new ArrayList<>();
    LinearLayout root; ListView list; TextView note; Button grant;
    boolean autoStarted = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        parseGames();
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF111418);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p * 2, p, p * 2, p);
        TextView h = new TextView(this);
        h.setText("Model 2 games"); h.setTextSize(22); h.setTextColor(0xFFFFFFFF);
        root.addView(h);
        note = new TextView(this);
        note.setTextColor(0xFFAAB4BE); note.setTextSize(14);
        root.addView(note);
        grant = new Button(this);
        grant.setText("Allow access to files");
        grant.setOnClickListener(v -> askAccess());
        root.addView(grant);
        list = new ListView(this);
        list.setDividerHeight(1);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
        // Builder mode: a game baked into the APK starts straight away.
        String fixed = readAsset("fixed_game.txt");
        if (!autoStarted && fixed != null && hasAccess()) {
            fixed = fixed.trim();
            Info i = games.get(fixed);
            if (!fixed.isEmpty() && i != null) {
                autoStarted = true;
                Entry e = new Entry(); e.set = fixed; e.title = title(i); e.mode = mode(i);
                start(e);
                finish();
            }
        }
    }

    boolean hasAccess() { return Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager(); }

    void askAccess() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) {}
    }

    void refresh() {
        entries.clear();
        boolean ok = hasAccess();
        grant.setVisibility(ok ? View.GONE : View.VISIBLE);
        File[] fs = new File(KeishoActivity.ROM_DIR).listFiles();
        if (ok && fs != null) {
            for (File f : fs) {
                String n = f.getName();
                if (!n.toLowerCase(Locale.ROOT).endsWith(".zip")) continue;
                String set = n.substring(0, n.length() - 4);
                Info i = games.get(set);
                if (i == null) continue;
                Entry e = new Entry(); e.set = set; e.title = title(i); e.mode = mode(i);
                entries.add(e);
            }
        }
        Collections.sort(entries, (a, b2) -> a.title.compareToIgnoreCase(b2.title));
        List<String> rows = new ArrayList<>();
        for (Entry e : entries) rows.add(e.title + "   (" + e.set + ")");
        list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, rows) {
            @Override public View getView(int pos, View cv, android.view.ViewGroup parent) {
                TextView t = (TextView) super.getView(pos, cv, parent);
                t.setTextColor(0xFFFFFFFF); t.setTextSize(18);
                return t;
            }
        });
        list.setOnItemClickListener((a, v, pos, id) -> start(entries.get(pos)));
        note.setText(!ok ? "Allow access to files, then come back."
            : entries.isEmpty() ? "No games found. Put ROM zips (for example hotd.zip) in " + KeishoActivity.ROM_DIR
            : "Tap a game to play. Folder: " + KeishoActivity.ROM_DIR);
    }

    void start(Entry e) {
        Intent i = new Intent(this, KeishoActivity.class);
        i.putExtra("game", e.set);
        i.putExtra("mode", e.mode);
        startActivity(i);
    }

    String title(Info i) {
        if (i.title != null) return i.title;
        Info p = i.parent == null ? null : games.get(i.parent);
        return p != null && p.title != null ? p.title : i.name;
    }

    int mode(Info i) {
        Set<String> t = i.types;
        if (t.isEmpty() && i.parent != null && games.get(i.parent) != null) t = games.get(i.parent).types;
        if (t.contains("gun1") || t.contains("analog_gun1")) return HudOverlay.MODE_GUN;
        if (t.contains("vehicle") || t.contains("handbrake") || t.contains("harley") || t.contains("magtruck"))
            return HudOverlay.MODE_RACE;
        return HudOverlay.MODE_PAD;
    }

    String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[1024]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toString("UTF-8");
        } catch (Exception e) { return null; }
    }

    void parseGames() {
        try (InputStream in = getAssets().open("games.xml")) {
            XmlPullParser p = Xml.newPullParser();
            p.setInput(in, "UTF-8");
            Info cur = null;
            for (int ev = p.getEventType(); ev != XmlPullParser.END_DOCUMENT; ev = p.next()) {
                if (ev == XmlPullParser.START_TAG) {
                    String n = p.getName();
                    if (n.equals("game")) {
                        cur = new Info();
                        cur.name = p.getAttributeValue(null, "name");
                        cur.parent = p.getAttributeValue(null, "parent");
                        if (cur.name != null) games.put(cur.name, cur);
                    } else if (cur != null && n.equals("title")) {
                        cur.title = p.nextText();
                    } else if (cur != null && n.equals("input")) {
                        String t = p.getAttributeValue(null, "type");
                        if (t != null) cur.types.add(t);
                    }
                } else if (ev == XmlPullParser.END_TAG && "game".equals(p.getName())) {
                    cur = null;
                }
            }
        } catch (Exception ignored) {}
    }
}

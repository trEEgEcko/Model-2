#!/usr/bin/env python3
"""Run from the repo root. Makes Keisho build as libmain.so for Android (SDL3 shared)."""
import re, sys, pathlib

def sub(path, old, new, count=1):
    p = pathlib.Path(path); s = p.read_text(encoding="utf-8")
    if old not in s:
        print(f"!! pattern not found in {path}: {old[:60]!r}"); sys.exit(1)
    p.write_text(s.replace(old, new, count), encoding="utf-8")

# 1. executable -> shared library "main" on Android
sub("src/CMakeLists.txt",
    "add_executable(keisho\n    main.cpp\n)",
    """if(ANDROID)
    add_library(keisho SHARED main.cpp)
    set_target_properties(keisho PROPERTIES OUTPUT_NAME main)
    target_link_libraries(keisho PRIVATE log android EGL GLESv3)
else()
    add_executable(keisho
        main.cpp
    )
endif()""")

# 2. SDL3 must be a shared lib on Android (SDLActivity loads libSDL3.so)
sub("cmake/Dependencies.cmake",
    "set(SDL_SHARED        OFF CACHE BOOL \"\" FORCE)\n    set(SDL_STATIC        ON  CACHE BOOL \"\" FORCE)",
    """if(ANDROID)
        set(SDL_SHARED    ON  CACHE BOOL "" FORCE)
        set(SDL_STATIC    OFF CACHE BOOL "" FORCE)
    else()
        set(SDL_SHARED    OFF CACHE BOOL "" FORCE)
        set(SDL_STATIC    ON  CACHE BOOL "" FORCE)
    endif()""")

# 3. SDL_main + app data dir as HOME/cwd (games.xml, keisho.ini, saves live there)
sub("src/main.cpp", "#include <SDL3/SDL.h>\n",
    "#include <SDL3/SDL.h>\n#include <SDL3/SDL_main.h>\n#if defined(__ANDROID__)\n#include <unistd.h>\n#include <stdlib.h>\n#endif\n")
sub("src/main.cpp", "int main(int argc, char** argv)\n{\n    using namespace sm2;\n",
    """int main(int argc, char** argv)
{
    using namespace sm2;
#if defined(__ANDROID__)
    if (const char* internal = SDL_GetAndroidInternalStoragePath()) {
        setenv("HOME", internal, 1);
        (void)chdir(internal);
    }
    if (!std::freopen("/storage/emulated/0/Model 2/keisho_log.txt", "w", stderr)) {
        (void)std::freopen("keisho_log.txt", "w", stderr);
    }
    setvbuf(stderr, nullptr, _IONBF, 0);
#endif
""")
# 4. Android tuning: deeper audio queue (stutter) and a phone-sized menu
sub("src/osd/audio.h",
    "static constexpr u32 kTargetQueuedMilliseconds = 80;\n    static constexpr u32 kMaxQueuedMilliseconds    = 200;",
    """#if defined(__ANDROID__)
    static constexpr u32 kTargetQueuedMilliseconds = 160;
    static constexpr u32 kMaxQueuedMilliseconds    = 400;
#else
    static constexpr u32 kTargetQueuedMilliseconds = 80;
    static constexpr u32 kMaxQueuedMilliseconds    = 200;
#endif""")
sub("src/osd/gui.cpp",
    "const float    sy = io.DisplaySize.y > 0.0f ? io.DisplaySize.y / 768.0f : 1.0f;",
    """#if defined(__ANDROID__)
    const float    sy = io.DisplaySize.y > 0.0f ? io.DisplaySize.y / 520.0f : 1.0f;  // bigger text on a phone
#else
    const float    sy = io.DisplaySize.y > 0.0f ? io.DisplaySize.y / 768.0f : 1.0f;
#endif""")
sub("src/main.cpp", "    setvbuf(stderr, nullptr, _IONBF, 0);\n",
    "    setvbuf(stderr, nullptr, _IONBF, 0);\n    SDL_SetHint(SDL_HINT_AUDIO_DEVICE_SAMPLE_FRAMES, \"2048\");\n    SDL_SetHint(SDL_HINT_ORIENTATIONS, \"LandscapeLeft\");\n    std::fprintf(stderr, \"[m2-android patch v5.2]\\n\");\n")
sub("src/osd/gui.cpp",
    "const ImVec2 size(std::min(vp->WorkSize.x - margin * 2.0f, kit.px(1000.0f)),",
    """#if defined(__ANDROID__)
    const float panel_w = kit.px(540.0f);   // narrow page: label and control sit close on a phone
#else
    const float panel_w = kit.px(1000.0f);
#endif
    const ImVec2 size(std::min(vp->WorkSize.x - margin * 2.0f, panel_w),""")
# 5. Phone-native wide mode: 496 + 2*179 = 854 px wide at 384 high = 20:9 (not stretched)
sub("src/render/backend.h", "constexpr u32 kWideColumns = 83;",
    """#if defined(__ANDROID__)
constexpr u32 kWideColumns = 179;   // 854x384 = 20:9
#else
constexpr u32 kWideColumns = 83;
#endif""")
sub("src/osd/gui.cpp",
    'static constexpr std::array<const char*, 4> kAspects = {N_("4:3"), N_("Square pixels"), N_("16:9"), N_("Stretch")};',
    """#if defined(__ANDROID__)
        static constexpr std::array<const char*, 4> kAspects = {N_("4:3"), N_("Square pixels"), N_("20:9"), N_("Stretch")};
#else
        static constexpr std::array<const char*, 4> kAspects = {N_("4:3"), N_("Square pixels"), N_("16:9"), N_("Stretch")};
#endif""")
sub("src/osd/gui.cpp", "16:9 draws the 3D wider", "Wide (16:9, or 20:9 on Android) draws the 3D wider")
# 6. Light-gun RELOAD button: the HUD sends key R, which Keisho treats like the right mouse button
#    (off-screen shot), so reload works in Stretch / fullscreen where there is no blank area to tap.
sub("src/osd/input.cpp",
    """        if (has_missile) {
            gi.trigger = pointer.left;
            gi.missile = pointer.right;
        } else {
            gi.trigger = pointer.left || pointer.right;
            gi.reload  = pointer.right;
        }
        return gi;""",
    """#if defined(__ANDROID__)
        const bool* hud_keys = SDL_GetKeyboardState(nullptr);
        const bool  hud_reload = hud_keys != nullptr && hud_keys[SDL_SCANCODE_R];
#else
        const bool  hud_reload = false;
#endif
        if (has_missile) {
            gi.trigger = pointer.left;
            gi.missile = pointer.right || hud_reload;
        } else {
            gi.trigger = pointer.left || pointer.right || hud_reload;
            gi.reload  = pointer.right || hud_reload;
        }
        return gi;""")
print("patch applied")

#!/usr/bin/env python3
"""Run from the repo root. Makes Keisho build as libmain.so for Android (SDL3 shared)."""
import re, sys, pathlib

def sub(path, old, new, count=1):
    p = pathlib.Path(path); s = p.read_text(encoding="utf-8")
    if old not in s:
        print(f"!! pattern not found in {path}: {old[:60]!r}"); sys.exit(1)
    p.write_text(s.replace(old, new, count), encoding="utf-8")

# 1. executable -> shared library "main" on Android
sub("src/CMakeLists.txt",
    "add_executable(keisho\n    main.cpp\n)",
    """if(ANDROID)
    add_library(keisho SHARED main.cpp)
    set_target_properties(keisho PROPERTIES OUTPUT_NAME main)
    target_link_libraries(keisho PRIVATE log android EGL GLESv3)
else()
    add_executable(keisho
        main.cpp
    )
endif()""")

# 2. SDL3 must be a shared lib on Android (SDLActivity loads libSDL3.so)
sub("cmake/Dependencies.cmake",
    "set(SDL_SHARED        OFF CACHE BOOL \"\" FORCE)\n    set(SDL_STATIC        ON  CACHE BOOL \"\" FORCE)",
    """if(ANDROID)
        set(SDL_SHARED    ON  CACHE BOOL "" FORCE)
        set(SDL_STATIC    OFF CACHE BOOL "" FORCE)
    else()
        set(SDL_SHARED    OFF CACHE BOOL "" FORCE)
        set(SDL_STATIC    ON  CACHE BOOL "" FORCE)
    endif()""")

# 3. SDL_main + app data dir as HOME/cwd (games.xml, keisho.ini, saves live there)
sub("src/main.cpp", "#include <SDL3/SDL.h>\n",
    "#include <SDL3/SDL.h>\n#include <SDL3/SDL_main.h>\n#if defined(__ANDROID__)\n#include <unistd.h>\n#include <stdlib.h>\n#endif\n")
sub("src/main.cpp", "int main(int argc, char** argv)\n{\n    using namespace sm2;\n",
    """int main(int argc, char** argv)
{
    using namespace sm2;
#if defined(__ANDROID__)
    if (const char* internal = SDL_GetAndroidInternalStoragePath()) {
        setenv("HOME", internal, 1);
        (void)chdir(internal);
    }
    if (!std::freopen("/storage/emulated/0/Model 2/keisho_log.txt", "w", stderr)) {
        (void)std::freopen("keisho_log.txt", "w", stderr);
    }
    setvbuf(stderr, nullptr, _IONBF, 0);
#endif
""")
# 4. Android tuning: deeper audio queue (stutter) and a phone-sized menu
sub("src/osd/audio.h",
    "static constexpr u32 kTargetQueuedMilliseconds = 80;\n    static constexpr u32 kMaxQueuedMilliseconds    = 200;",
    """#if defined(__ANDROID__)
    static constexpr u32 kTargetQueuedMilliseconds = 160;
    static constexpr u32 kMaxQueuedMilliseconds    = 400;
#else
    static constexpr u32 kTargetQueuedMilliseconds = 80;
    static constexpr u32 kMaxQueuedMilliseconds    = 200;
#endif""")
sub("src/osd/gui.cpp",
    "const float    sy = io.DisplaySize.y > 0.0f ? io.DisplaySize.y / 768.0f : 1.0f;",
    """#if defined(__ANDROID__)
    const float    sy = io.DisplaySize.y > 0.0f ? io.DisplaySize.y / 520.0f : 1.0f;  // bigger text on a phone
#else
    const float    sy = io.DisplaySize.y > 0.0f ? io.DisplaySize.y / 768.0f : 1.0f;
#endif""")
sub("src/main.cpp", "    setvbuf(stderr, nullptr, _IONBF, 0);\n",
    "    setvbuf(stderr, nullptr, _IONBF, 0);\n    SDL_SetHint(SDL_HINT_AUDIO_DEVICE_SAMPLE_FRAMES, \"2048\");\n")
print("patch applied")

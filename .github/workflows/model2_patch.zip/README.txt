model2_patch.zip - Keisho (Sega Model 1/2/3) Android wrapper, first scaffold. UNTESTED.
1) Upload this zip as .github/workflows/model2_patch.zip, plus android.yml to .github/workflows/
2) Actions > "Android APK" > Run workflow, game_id = hotd (or manxtt, daytona, srallyc ...)
3) ROMs: /storage/emulated/0/Model 2/<set>.zip  (grant "All files access" on first launch, then reopen)

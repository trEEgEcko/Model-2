model2_patch.zip v5 - Keisho (Sega Model 1/2/3) Android wrapper. Still untested as a whole.
1) Upload this zip as .github/workflows/model2_patch.zip (plus android.yml) to your fork, run "Android APK".
2) ROMs: /storage/emulated/0/Model 2/<set>.zip. Open the app, allow file access, pick a game from the list.
3) v5: launcher with game list, game runs in its own process, 20:9 wide mode on Android, HUD kept clear of the right edge, HUD modes: gun / racing / generic pad.
4) Build-time single-game (for the future builder): put a set name in assets/fixed_game.txt and the app starts it directly.
